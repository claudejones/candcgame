OC01 work in progress. Read delivery/OC01_check_report.md. MID coverage is blocked; do not import this checkpoint as a completed five-PNG stage. Four passing assets are in delivery/.
