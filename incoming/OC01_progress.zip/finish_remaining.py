from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib,shutil
p=Path('oc01').resolve();src=Path('generated_images').resolve();(p/'prepared').mkdir(exist_ok=True)
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
# Explicit separately reviewed margin decision, not an expansion of the helper limits.
g=src/'exec-0bcb93da-901c-40e9-8ac0-d1c38a3e97ca.png';im=Image.open(g).convert('RGBA');a=np.array(im)
assert a.shape==(724,2172,4) and a[333:,:,3].min()>=240 and a[:332,:,3].max()<=8
clean=im.copy();clean.putalpha(clean.getchannel('A').point(lambda v:0 if v<=8 else v));clean.paste((0,0,0,0),(0,332,2172,333))
cut=clean.crop((0,333,2172,664));cut.putalpha(255)
out=Image.new('RGBA',(2172,724));out.paste(cut,(0,393));prepared=p/'prepared/ground-aligned.png';out.save(prepared)
decision={'source':str(g),'source_sha256':sha(g),'reason':'Focused generation added more depth than requested. The true flat soil cap is row333; aligning it requires a60px downward translation and removal of60 bottom margin rows. This exceeds routine helper trim36 and is recorded as a separate content-preserving margin decision under the requested correction workflow; helper limits remain unchanged. No landmark, prop or subject is cropped.','operations':[{'clear_empty_space_above':332,'max_alpha':8},{'remove_surface_matting_row':332,'alpha_range':[47,83]},{'opaque_existing_soil': [0,333,2172,664],'min_alpha':240},{'trim_bottom_rows':60},{'translate_y':60}],'output':str(prepared),'output_sha256':sha(prepared)}
(p/'ground-margin-decision.json').write_text(json.dumps(decision,indent=2))
jobs=[{'kind':'GROUND','source':str(prepared),'source_sha256':sha(prepared),'filename':'OC01_GROUND_ULURU.png','pieces':[{'region':[0,0,2172,724],'anchor':[0,393],'anchor_evidence':'Flat soil cap at originalrow333 moved+60 under separate logged margin correction; actual final surface393.'}]}]
(p/'ground-plan.json').write_text(json.dumps({'stage':'OC01','images':jobs},indent=2))
o=src/'exec-8500a45b-47fe-40aa-a711-5f1218a19cda.png';f=src/'exec-0bff64b1-94f9-4701-aace-8b8b1b2bf899.png'
objects={'kind':'OBJECT_ATLAS','source':str(o),'source_sha256':sha(o),'filename':'OC01_OBJECT_ATLAS.png','scale':.97,'correction_reason':'Generated spinifex crosses nominal source midpoint; split only at empty gapx1300 and place full silhouettes in equal finalcells. Same.97 scale preserves post top gutter. Clear faint background residue.','corrections':{'clear_below_alpha':8},'pieces':[{'region':[0,0,1300,724],'anchor':[690,640],'anchor_evidence':'Center of compact rooted core atx690 and its flat basey640; lower projecting grass tips are not the root contact.'},{'region':[1300,0,2171,724],'anchor':[428,660],'anchor_evidence':'Midpoint of flat dark underside of post foot atglobalx1728,row660.'}]}
flying={'kind':'FLYING','source':str(f),'source_sha256':sha(f),'filename':'OC01_HAZARD_GALAH.png','scale':.88,'correction_reason':'Common scale.88 gives wingtip and tail gutters while aligning same torso feature; source2170x725 is placed into four equal543x724 cells, no subject cropped.','corrections':{'clear_below_alpha':8},'pieces':[]}
for i,dx in enumerate([0,-2,-1,-3]):
 flying['pieces'].append({'region':[543*i,0,min(543*(i+1),2170),725],'anchor':[315+dx,422],'anchor_evidence':f'Pink torso feature at local({315+dx},422), registered to first frame by unchanged eye/head crop (offset{dx},0), independent of wing silhouette.'})
(p/'sprites-plan.json').write_text(json.dumps({'stage':'OC01','images':[objects,flying]},indent=2))
for q in [g,o,f,src/'exec-66bd16f8-9e6b-4481-87a1-591542832c89.png']:shutil.copy2(q,p/'originals'/q.name)
