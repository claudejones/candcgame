from PIL import Image,ImageDraw
from pathlib import Path
import json,hashlib,shutil
p=Path('oc01').resolve();src=Path('generated_images').resolve()
files={'FAR':'exec-e621ca63-0ca1-4b22-838e-3f58117f39aa.png','MID':'exec-d2bda150-ead4-4967-a035-bced8cf09b4f.png'}
js=[]
for k,n in files.items():
 f=src/n;shutil.copy2(f,p/'originals'/n);im=Image.open(f)
 j={'kind':k,'source':str(f),'source_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'filename':f'OC01_BG_{"DISTANT" if k=="FAR" else "MID"}_ULURU.png','pieces':[{'region':[0,0,*im.size]}]}
 if k=='MID':
  j.update(horizontal_extension='wrap',correction_reason='Remove faint sky residue, normalize existing solid lower soil, repeat one missing edge column.',corrections={'clear_below_alpha':8,'opaque_regions':[{'region':[0,621,im.width,724],'min_alpha':251}]})
  j['pieces'][0].update(anchor=[0,621],anchor_evidence='Authored lower red-earth shelf baseline at row621, below kangaroo feet and shrub contacts; existing continuous soil extends beneath it.')
 js.append(j)
(p/'landscape-plan.json').write_text(json.dumps({'stage':'OC01','images':js},indent=2))
