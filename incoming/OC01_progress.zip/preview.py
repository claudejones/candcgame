from PIL import Image,ImageDraw
from pathlib import Path
p=Path(__file__).parent
base=960/2172
far=Image.open(p/'landscape-final/OC01_BG_DISTANT_ULURU.png').convert('RGBA').resize((1200,400),Image.Resampling.NEAREST)
mid=Image.open(p/'landscape-final/OC01_BG_MID_ULURU.png').convert('RGBA').resize((960,320),Image.Resampling.NEAREST)
gp=p/'ground-final/OC01_GROUND_ULURU.png'
ground=Image.open(gp).convert('RGBA').resize((960,320),Image.Resampling.NEAREST) if gp.exists() else None
sheet=Image.new('RGB',(1280,5*380),'#dfddd2');dr=ImageDraw.Draw(sheet)
for i,pos in enumerate([0,5400,10800,2400,4800]):
 f=Image.new('RGBA',(960,540),'#dfddd2');f.alpha_composite(far,(0,0));c=f.copy()
 x=-round(pos*.2)%960
 for xx in [x-960,x]:c.alpha_composite(mid,(xx,round(410-621*base)))
 if ground:
  x=-round(pos)%960
  for xx in [x-960,x]:c.alpha_composite(ground,(xx,round(410-393*base)))
 else:ImageDraw.Draw(c).line((0,410,960,410),fill='white',width=2)
 for j,im in enumerate([f,c]):sheet.paste(im.resize((640,360)),(j*640,i*380+20))
 dr.text((3,i*380+3),f'OC01 x={pos} FAR alone',fill='black');dr.text((645,i*380+3),'Canonical composite',fill='black')
sheet.save(p/'qa/landscape-review.jpg')
for n in ['DISTANT','MID']:
 im=Image.open(p/f'landscape-final/OC01_BG_{n}_ULURU.png').convert('RGBA');b=Image.new('RGBA',(600,724),'#cad5df');b.alpha_composite(im.crop((1872,0,2172,724)),(0,0));b.alpha_composite(im.crop((0,0,300,724)),(300,0));b.convert('RGB').save(p/f'qa/{n}-join.jpg')
