# OC01 — Uluru: progress and remaining correction

**Status: blocked on MID coverage. Four assets are finished; the five-PNG Workbench ZIP is not ready.**

Approved obstacle replacement: weathered timber trail-marker post paired with a spinifex tussock.

| Asset | Result |
|---|---|
| OC01_BG_DISTANT_ULURU.png | Pass: 2172 × 724, opaque, clean repeat join; recognizable Uluru profile remains visible at all sampled scroll positions. |
| OC01_BG_MID_ULURU.png | Geometry passes for the first candidate, but combined-scene coverage fails. A focused artistic extension did not resolve the issue. Both candidates preserved. |
| OC01_GROUND_ULURU.png | Pass: 2172 × 724, transparent above exact surface row393, solid opaque below, level repeat. |
| OC01_OBJECT_ATLAS.png | Pass: two 1086 × 724 cells, semantic root/post contacts at (543,620), uniform97% scale, complete silhouettes, minimum gutter38px. |
| OC01_HAZARD_GALAH.png | Pass: four543 × 724 cells, stable body feature at (271,362), right-facing, four distinct wing poses, uniform88% scale, minimum gutter35px. |

## Remaining issue

At canonical 960 × 540 presentation, FAR covers through screen row399, MID draws at y136, and GROUND starts at y410. The first MID leaves fully transparent strips in rows400–404: 185,169,164,104 and33 columns respectively at scroll position0. Partially transparent edge pixels remain below those strips. The focused MID correction still has incomplete source coverage through approximately row605. Filling below source row590 was requested but not achieved.

The next correction must extend the MID's existing red-earth shelf upward until the layer covers the strip between FAR and GROUND at every horizontal position, preserving both trees, both kangaroos, source baseline621, zero visual offsets and scale1. No configuration displacement should conceal this defect. The candc-stage-images one-focused-retry rule stops further automatic artistic attempts here.

## Completed corrections and verification

MID candidate: removed faint alpha≤8, normalized existing lower soil opacity, repeated one missing edge column. Its exact canvas and lower-anchor checks pass, but those checks do not certify combined coverage.

GROUND: the first candidate lacked enough lower depth. One focused edit supplied extra depth. A separately explained margin decision removed one partial-alpha surface row, normalized existing soil with alpha≥240, moved the actual cap from333 to393 and removed60 surplus bottom rows. This60-row trim exceeds the helper's routine36-row allowance and is explicitly recorded separately; the helper was not changed. No subjects or props were cropped.

OBJECT_ATLAS: separated source objects at an empty gap because the grass extended across the nominal source midpoint; uniformly scaled both97% and placed them into equal final cells. Ground anchors use the central root base and flat post-foot underside, not projecting blades.

FLYING: cleared faint alpha, aligned the same torso feature using the head/eye correspondence, scaled every pose88%, and placed the2170 × 725 source into the canonical atlas without clipping. Four-pose contact sheet and animation preview were produced.

FAR-alone and combined views inspected at worldX0,5400,10800,2400,4800 with multipliers1.25/1/1, parallax0/.20/1, offsets0 and surface410. Uluru's top and broad mass remain visible, and depth reads clearly. Ground and landscape repeat joins pass. The coverage defect above is the only outstanding visual blocker.

Reference checks: [Uluru geographic identity](https://whc.unesco.org/en/list/447/), [Parks Australia red kangaroo](https://uluru.gov.au/discover/nature/animals/mammals/red-kangaroo/), [BirdLife galah identification](https://birdlife.org.au/bird-profiles/galah/), [Australian Museum galah flight and range](https://australian.museum/learn/animals/birds/galah/). No external reference photographs were attached to generation.

Originals, measured plans, separate margin decision, final passing PNGs and QA previews are retained in OC01_progress.zip. This is a working checkpoint, not a Workbench import ZIP. No import, calibration, Git publication or deployment was performed.
